export class Healthinsurance {
    constructor(
        public id : number,
        public policyname : string,
        public sumassurance : number,
        public monthleypay : number,
        public noofmonths : number,
        public diseasescovered : string,
        public hospitals : string,
    ){}
}
