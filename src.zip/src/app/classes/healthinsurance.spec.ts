import { Healthinsurance } from './healthinsurance';

describe('Healthinsurance', () => {
  it('should create an instance', () => {
    expect(new Healthinsurance()).toBeTruthy();
  });
});
