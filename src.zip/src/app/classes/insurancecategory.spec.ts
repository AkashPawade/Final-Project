import { Insurancecategory } from './insurancecategory';

describe('Insurancecategory', () => {
  it('should create an instance', () => {
    expect(new Insurancecategory()).toBeTruthy();
  });
});
