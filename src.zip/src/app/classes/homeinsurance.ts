export class Homeinsurance {
    constructor(
        public id : number,
        public policyname : string,
        public city : string,
        public areaname : string,
        public monthleypremium : number,
        public sumassurance : number,
        public time : number,
        public categoryid : number
    ){}
}
