export class Insurancecategory {
    constructor(
        public id : number,
        public category : string
    ){}
}
