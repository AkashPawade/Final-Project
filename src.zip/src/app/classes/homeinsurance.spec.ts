import { Homeinsurance } from './homeinsurance';

describe('Homeinsurance', () => {
  it('should create an instance', () => {
    expect(new Homeinsurance()).toBeTruthy();
  });
});
